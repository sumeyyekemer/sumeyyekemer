import java.util.Random;
public class Ticket {

    public int ticketNo()
    {
        Random r=new Random(); //random sınıfı
        int a=r.nextInt(10);
        return a;
    }

}
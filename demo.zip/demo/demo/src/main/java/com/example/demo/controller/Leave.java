@Controller
public class LeaveController {
    @Autowired
    ServiceClass serviceClass;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String (Car car) {
        model.addAttribute("user", new User());
        return "register";
    }

}
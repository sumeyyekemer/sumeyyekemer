@Transactional
@Service
public class serviceClass {

    Car car = new Car();
    Ticket ticket;
    car.setSlot(ticket.ticketNo());

}